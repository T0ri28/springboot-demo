package com.example.demoweb.controller;

import com.example.demoweb.Repository.PostRepository;
import com.example.demoweb.Repository.SearchRepository;
import com.example.demoweb.model.Post;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Controller  // Chỉ định HomeController là Controller
public class HomeController {

    @Autowired
    PostRepository repo;

    @Autowired
    SearchRepository srepo;

    // Khi user truy cập vào endpoint / thì homepage*() được gọi

    @GetMapping("/")
    public String homepage1() {
        return "trangchu";  // Trả về trang trangchu.html
    }

    @GetMapping("/{option}")
    public String homepage2(@PathVariable String option) {
        if ("dang-thong-tin-tuyen-dung.html".equals(option)) {
            return "dangthongtintuyendung";  // Trả về trang dangthongtintuyendung.html
        }
        else if ("tim-kiem-viec-lam.html".equals(option)) {
            return "timkiemvieclam";  // Trả về trang timkiemvieclam.html
        }
        return "trangchu"; // Mặc định, trả về trang trangchu.html
    }

    @GetMapping("/tim-kiem-viec-lam")
    public List<Post> getAllPost()
    {
        return repo.findAll();
    }

    @GetMapping("/tim-kiem-viec-lam.html?searchInput={option1}")
    public List<Post> searchPost(@PathVariable String option1)
    {
        return srepo.findByText(option1);
    }

    @PostMapping("/luuthongtin")
    public Post addPost(@RequestBody Post luuthongtin)
    {
        return repo.save(luuthongtin);
    }

    // Có thể mapping thêm các endpoint khác nữa...
}
